﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

namespace JuniorApplication
{
    public partial class About : Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            DataSet ds = GetData();
            Repeater1.DataSource = ds;
            Repeater1.DataBind();
        }
        private DataSet GetData()
        {
            string CS = ConfigurationManager.ConnectionStrings["DatabaseConnectionString"].ConnectionString;
            using (SqlConnection con = new SqlConnection(CS))
            {
                SqlDataAdapter da = new SqlDataAdapter("Select * from tblEmployee", con);
                DataSet ds = new DataSet();
                da.Fill(ds);
                return ds;
            }
        }

        protected void Repeater1_ItemCommand(object source, RepeaterCommandEventArgs e)
        {
            /*
            if (e.Item.ItemType == ListItemType.Item || e.Item.ItemType == ListItemType.AlternatingItem)
            {
                if (e.CommandName == "ShowSkills") // check command is cmd_delete
                {
                    // get you required value
                   // int CustomerID = Convert.ToInt32(e.CommandArgument);
                    LinkButton button = e.CommandSource as LinkButton;


                    //Write some code for what you need 
                    //Get the Repeater Item reference
                   // RepeaterItem item = button.NamingContainer as RepeaterItem;

                    //Get the repeater item index
                   // int index = item.ItemIndex;

                } */
          //  } 
             
            

        }
    }
}